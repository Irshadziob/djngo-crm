import random
from django.shortcuts import render, reverse
from django.views import generic
# --> user login important
from django . contrib . auth . mixins import LoginRequiredMixin
from leads.models import Agent
from . forms import AgentModelForm
from . mixins import OrganiserAndLoginRequiredMixin
from django.core.mail import send_mail


# ___________________________________________________________
# ------> Creating Agent List View
class AgentListView(OrganiserAndLoginRequiredMixin, generic.ListView):
    template_name = "agents/agent_list.html"

    # -> queryset = Agent.objects.all() -->its one method
    def get_queryset(self):
        # --> this code grab user profile mod for logged user
        organisation = self.request.user.userprofile
        # --> passing value
        return Agent.objects.filter(organisation=organisation)

# _________________________________________________________

# ____________________________________________________________
# -----> Agent Create view


class AgentCreateView(OrganiserAndLoginRequiredMixin, generic.CreateView):
    template_name = "agents/agent_create.html"
    form_class = AgentModelForm

    def get_success_url(self):
        return reverse("agents:agent_list")

    def form_valid(self, form):  # ----> this function for organistion error
        user = form.save(commit=False)  # ---> we cant save commit
        user.is_agent = True
        user.is_organiser = False
        user.set_password(f"{random.randint(0,1000000)}") #--> super password
        user.save()
        Agent.objects.create(
            user=user,
            organisation=self.request.user.userprofile,

        )

        send_mail(
            subject="You are invited into agent",
            message="Please work",
            from_email="admin@mail.com",
            recipient_list=[user.email]
        )

        # agent.organisation = self.request.user.userprofile
        # agent.save()
        return super(AgentCreateView, self).form_valid(form)

# ___________________________________________________________
# -------> Agent Detail View


class AgentDetailView(OrganiserAndLoginRequiredMixin, generic.DetailView):
    template_name = "agents/agent_detail.html"  # --> template rendering
    context_object_name = "agent"

    def get_queryset(self):
        # --> this code grab user profile mod for logged user
        organisation = self.request.user.userprofile
        # --> passing value
        return Agent.objects.filter(organisation=organisation)
# __________________________________________________________________

# ---->Agent Create View


class AgentUpdateView(OrganiserAndLoginRequiredMixin, generic.UpdateView):
    template_name = "agents/agent_update.html"
    form_class = AgentModelForm

    # -> queryset = Agent.objects.all() -->its one method
    def get_queryset(self):
        return Agent.objects.all()

    def get_success_url(self):
        return reverse("agents:agent_list")


# _____________________________________________________________

class AgentDeleteView(OrganiserAndLoginRequiredMixin, generic.DeleteView):
    template_name = "agents/agent_delete.html"  # --> template rendering
    context_object_name = "agent"

    def get_success_url(self):
        return reverse("agents:agent_list")
     # -> queryset = Agent.objects.filter() -->its one method

    def get_queryset(self):
        # --> this code grab user profile mod for logged user
        organisation = self.request.user.userprofile
        # --> passing value
        return Agent.objects.filter(organisation=organisation)
# __________________________________________________________________
