from django import forms
from . models import Lead
from django.contrib.auth.forms import UserCreationForm,UsernameField
from django . contrib .auth import get_user_model 

User = get_user_model()

#__________________________________________________
#--------> Creating Lead form
class LeadModelForm(forms.ModelForm):
    class Meta:
        model = Lead #---> Class name
        fields = ( #-----> class fields
            'first_name',
            'last_name',
            'age',
            'agent',
        )
#________________________________________________________
#---------------->NOT USING
# CUSTOM CODE WAY TO CREATE MODEL
#------> CHECK def createview(request)
class LeadForm(forms.Form):
    first_name = forms.CharField() 
    last_name = forms.CharField()
    age = forms.IntegerField()
#_____________________________________________________


#___________________________________________________
#------------->USER CREATION FORM {DJANGO BUILT IN}
#from django.contrib.auth.forms import UserCreationForm,UsernameField
class CustomUserCreationForm(UserCreationForm):
    class Meta:
        #-->User = get_user_model()  
        model = User #----> from django . contrib .auth import get_user_model              
        fields = (
            "username",
        )
        field_classes = {'username':UsernameField}
