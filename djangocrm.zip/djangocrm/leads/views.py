
from django.shortcuts import redirect, render, reverse 
# from django.urls import reverse
from .models import Lead, Agent, UserProfile  # ---> its from models
# -----> its from forms
from . forms import LeadForm, LeadModelForm, CustomUserCreationForm
# ----> this used for class base CRUD-L {{django builtin}}
from django.views import generic
from django.core.mail import send_mail #--> mail send
from django.contrib.auth.forms import UserCreationForm
# ---->(LoginRequiredMixin ---> checking user login. not login redirect to login page)--> (after login redirect to current page)
from django . contrib . auth . mixins import LoginRequiredMixin
from agents . mixins import OrganiserAndLoginRequiredMixin
# Create your views here.

"""
------->IMPORTANT NOTES<--------
AUTHENTICATED MEANS USER LOG-IN

"""


# ----------------------------------------------------
# -----> User creation form on sign up
class SignupView(generic.CreateView):
    # ---> its important use registration folder other ways throw error
    template_name = "registration/signup.html"
    form_class = CustomUserCreationForm  # ---> check forms.py

    def get_success_url(self):
        return reverse('login')
# ----------------------------------------------------------


# CRUD CLASS BASED VIEWS AND FUNCTION BASED VIEWS
# _____________________________________________________________________
# --------------->CLASS BASED VIEWS OF LANDING PAGE <-------------------
# ---------------->FUNCTION BASED CLASS ONY USING


class LandingPageView(LoginRequiredMixin, generic.TemplateView):
    # from django . views . generic import TemplateView
    template_name = "landing.html"
# _______________________________________________________________________

# ----------> FUNCTION BASED VIEWS OF LANDING_PAGE <-------------------
# ------------>NOT USING


def landing(request):
    return render(request, 'landing.html')

# ________________________________________________________________________
# __________________________________________________________________________

# _________________________________________________________________________
# -------------------------->CLASSBASED LIST VIEW <---------------------
# ------------------------->USING


class LeadListView(LoginRequiredMixin, generic.ListView):
    # from django . views . generic import  ListView
    template_name = 'index.html'  # ----> Name of the template
    # queryset = Lead.objects.all()  # ----> Get value from Model(DataBase)
    # ----> Send Value to Template (call ->leads on template)
    context_object_name = "leads"
#   initial queryset for entire organisation

    def get_queryset(self):
        # its little bit tricky check models to understand
        user = self.request.user  # --> checking user
        if user.is_organiser:
            # --> is user organiser user have user profile
            queryset = Lead.objects.filter(organisation=user.userprofile)

        else:  # --> user orgsniser allel agent aavum anagananel
            queryset = Lead.objects.filter(
                organisation=user.agent.organisation)  # --> so agent organisation
            # filter for that the agent logged in
            queryset = queryset.filter(agent__user=user)

        return queryset
# __________________________________________________________________________

# --------------------->FUNCTION BASED LIST VIEW<---------------------
# --------------------->NOT USIB CLASS BASED NOW


def home(request):
    leads = Lead.objects.all()
    context = {
        "leads": leads
    }
    return render(request, 'index.html', context)

# _________________________________________________________________________
# _________________________________________________________________________


# _________________________________________________________________________
# --------------< CLASS BASED DETAIL VIEW <----------------------------
# ---------------> USING
class LeadDetailView(LoginRequiredMixin, generic.DetailView):
    # from django . views . generic import DetailView
    template_name = 'listing.html'  # ------->template name
    # queryset = Lead.objects.all()  # ----> Get value from Model(DataBase)
    # ----> Send Value to Template (call ->listing on template)
    context_object_name = "listing"

    def get_queryset(self):
        # its little bit tricky check models to understand
        user = self.request.user  # --> checking user
        if user.is_organiser:
            # --> is user organiser user have user profile
            queryset = Lead.objects.filter(organisation=user.userprofile)

        else:  # --> user orgsniser allel agent aavum anagananel
            queryset = Lead.objects.filter(
                organisation=user.agent.organisation)  # --> so agent organisation
            # filter for that the agent logged in
            queryset = queryset.filter(agent__user=user)

        return queryset
# _________________________________________________________________________
# --------------->FUNCTION BASED DETAILVIEW <----------------------------
# --------------->NOT USING


def fullview(request, pk):  # -----> DETAIL VIEW
    listing = Lead.objects.get(id=pk)
    context = {
        "listing": listing
    }
    return render(request, 'listing.html', context)
# ________________________________________________________________________
# ________________________________________________________________________


# ____________________________________________________________________
# --------------> CLASS BASED CREATE VIEW<--------------------------
# --> organiser login mixin for its custom mixin for agent n lead create cheyyaan pattoola
class LeadCreateView(OrganiserAndLoginRequiredMixin, generic.CreateView):

    # from django . views . generic import CreateView
    template_name = 'create.html'
    # from . forms import  LeadModelForm
    form_class = LeadModelForm  # ------> created on forms check form

    def get_success_url(self):  # ----->built in function
        # from django . shortcuts import reverse
        return reverse("leads:landing")  # -------->used namespace

    def form_valid(self,form):
        #TODO MAIL SEND
        send_mail(
            subject = " A mail has created",
            message= " Go to site see lead",
            from_email="test@test.com",
            recipient_list=["test2@test.com"]
        )
        return super(LeadCreateView,self).form_valid(form)

# ________________________________________________________________________
# ---------------------->FUNCTION BASED CREATE VIEW<--------------------


def leadmodelform(request):  # ----> CREATE
    form = LeadModelForm()  # ------> VALU FETCH FROM FORM
    if request.method == 'POST':
        # --------> VALUE FETCH FROM TEMPLATE
        form = LeadModelForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/')  # ------> AFTER SUBMIT '/'ROOT PAGE

    context = {
        "form": form
    }
    return render(request, 'create.html', context)
# ________________________________________________________________________
# _________________________________________________________________________


# ___________________________________________________________________________
# agent n lead update cheyyaan pattoola
class LeadUpdateView(OrganiserAndLoginRequiredMixin, generic.UpdateView):
    # from django . views . generic import UpdateView
    template_name = 'update.html'  # ---->template name
    # queryset = Lead.objects.all()  # ----> VALUE FETCHING ON MODELS LEAD
    form_class = LeadModelForm  # --------->FETCHING FORM TEMPLATE

    def get_queryset(self):
        # its little bit tricky check models to understand
        user = self.request.user  # --> checking user
        return Lead.objects.filter(organisation=user.userprofile)

    def get_success_url(self):
        # ---------->AFTER UPDATE NAVIGATING WHERE
        return reverse('leads:landing')
# ___________________________________________________________________________
# ------------------>FUNCTIONBASED CREATE VIEW <---------------------


def leadupdate(request, pk):  # --------->PK IS PRIMARY KEY TO DB
    lead = Lead.objects.get(id=pk)  # FETCHING ID VALUE
    # ITS DJANGO INSTANCE
    form = LeadModelForm(request.POST or None, instance=lead)

    if form.is_valid():
        form.save()
        return redirect('/')
    context = {
        "form": form,
        "lead": lead
    }
    return render(request, 'update.html', context)

# ______________________________________________________________________
# _______________________________________________________________________


# __________________________________________________________________
# ------------------------> CLASS BASED DELETE VIEW<----------------
class LeadDeleteView(LoginRequiredMixin, generic.DeleteView):
    # django . views . generic import DeleteView
    template_name = 'delete.html'  # class based view need a template to delete
    #queryset = Lead.objects.all()  # fetching value from db

    def get_success_url(self):
        return reverse('leads:landing')

    def get_queryset(self):
        # its little bit tricky check models to understand
        user = self.request.user  # --> checking user
        return Lead.objects.filter(organisation=user.userprofile)
# ____________________________________________________________________
# ------------------> function based delete view
# THIS CODE NOT USE TEMPLATE TO DELETE IF WANT THEN USE


def lead_delete(request, pk):
    lead = Lead.objects.get(id=pk)
    lead.delete()  # -----------> no need to pass template  but use urls.py <int:pk>/delete/
    return redirect('/')
# ________________________________________________________________________


# ____________________________________________________________________________
# ----------------> FORMS CUSTOM FOR STSRTING BEGINNER<------------------
# -----------------> CHECK FORMS.PY -> CLASS LeadForm()
"""
def createview(request):
    form = LeadForm()
    if request.method == "POST":
        print('recieved')
        form = LeadForm(request.POST)
        if form.is_valid():
            first_name = form.cleaned_data['first_name']
            last_name = form.cleaned_data['last_name']
            age = form.cleaned_data['age']
            agent = Agent.objects.first()
            Lead.objects.create(
                first_name = first_name,
                last_name = last_name,
                age = age ,
                agent = agent

            )
            return redirect('/')

    context = {
        "form":LeadForm
    }
    return render (request,'create.html',context)
"""
