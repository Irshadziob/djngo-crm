from django.db import models
from django.contrib.auth.models import AbstractUser
from django . db . models . signals import post_save #--> is user created its create corresponding userprofile and saving hes data


# Create your models here.
#____________________________________________________
#from django.contrib.auth.models import AbstractUser
#---> django builtin User{{User is a variable }} model
#class User(AbstractUser): --> normally we need only pass
 #   pass
class User(AbstractUser):
    is_organiser = models.BooleanField(default=True) #--> we create a account defaultly we organiser
    is_agent = models.BooleanField(default=False)
#_____________________________________________________

class UserProfile(models.Model): #-----> Creating user profile save user details
    user = models.OneToOneField(User,on_delete=models.CASCADE) #-------> onetwoonefield its like a foriegn field
    
    def __str__(self):
        return self.user.username




#-----------> creating Lead Model
class Lead(models.Model):

    first_name = models.CharField(max_length=20)
    last_name= models.CharField(max_length=20)
    age = models.IntegerField(default=0)
    organisation = models.ForeignKey(UserProfile, on_delete=models.CASCADE) #
    agent = models.ForeignKey('Agent', null= True , blank=True,  on_delete=models.SET_NULL) #--->  'Agent', on_delete=models.CASCADE -> this is need 
   #--> if a agent signed into lead and we delete a agent and not thats agent lead deleted anymore
    def __str__(self):
        return f"{self.first_name} {self.last_name}" #---> value to show admin panel
  


#________________________________________________________________________

class Agent(models.Model):
    user = models.OneToOneField(User,on_delete=models.CASCADE) #-------> onetwoonefield its like a foriegn field
    organisation = models.ForeignKey(UserProfile, on_delete=models.CASCADE) #----> delete user compeletely delete all data
    def __str__(self):
        return self.user.email
  

#____________________________________________________________________________

def post_user_created_signals(sender,instance,created, **kwargs):
    if created:
        UserProfile.objects.create(user=instance)  #----> this function automatically create user profile


post_save.connect(post_user_created_signals, sender=User) #-->

#______________________________________________________________________